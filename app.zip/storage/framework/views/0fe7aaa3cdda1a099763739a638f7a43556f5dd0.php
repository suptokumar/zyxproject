
<?php $__env->startSection("title",__("ZYX Admin Panel")); ?>
<?php $__env->startSection("page"); ?>
<div class="breadcrumb">
    <h1>ZYX</h1>
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
        <li>Edit vendor</li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>


<div class="row justify-content-center">
    <div class="col-md-6">
        <?php if(session('successfully')): ?>
        <div class="alert alert-success text-center">
            <?php echo e(session('successfully')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(url('update-vendor')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="vendor_id" value="<?php echo e($editvendor->id); ?>">
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($editvendor->name); ?>" id="" aria-describedby="emailHelp" placeholder="Enter Name">
            </div>
            <div class="form-group">
                <label for="">Email address</label>
                <input type="email" class="form-control" name="email" value="<?php echo e($editvendor->email); ?>" id="" aria-describedby="emailHelp"placeholder="Enter email">
            </div>
            <div class="form-group">
                <label for="">Password </label>
                <input type="text" class="form-control" name="password" value="<?php echo e($editvendor->password); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">OTP Verified </label>
                <select class="form-control" name="otp_verified">
                    <option value="1" <?php echo e($editvendor->otp_verified==1?'selected':""); ?>>Yes</option>
                    <option value="0" <?php echo e($editvendor->otp_verified==0?'selected':""); ?>>No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="">Store Name </label>
                <input type="text" class="form-control" name="store_name" value="<?php echo e($editvendor->store_name); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Store Category </label>
                <input type="text" class="form-control" name="store_category" value="<?php echo e($editvendor->store_category); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Store Category ID</label>
                <input type="text" class="form-control" name="store_category_id" value="<?php echo e($editvendor->store_category_id); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Country Code </label>
                <input type="text" class="form-control" name="country_code" value="<?php echo e($editvendor->country_code); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">WhatsApp</label>
                <input type="text" class="form-control" name="whatsapp" value="<?php echo e($editvendor->whatsapp); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Phone</label>
                <input type="text" class="form-control" name="phone" value="<?php echo e($editvendor->phone); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Address</label>
                <input type="text" class="form-control" name="address" value="<?php echo e($editvendor->address); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Logo</label>
                <input type="file" class="form-control" name="logo" id="logo" aria-describedby="emailHelp" placeholder="">
                <?php if($editvendor->logo!=''): ?>
                <label for="logo">
                <img src="<?php echo e(url($editvendor->logo)); ?>" alt="" style="width:100px;">
                </label>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="">Featured Image</label>
                <input type="file" id="featured_image" class="form-control" name="featured_image" value="" aria-describedby="emailHelp" placeholder="">
                <?php if($editvendor->featured_image!=''): ?>
                <label for="featured_image">
                <img src="<?php echo e(url($editvendor->featured_image)); ?>" alt="" style="width:100px;">
                </label>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="">URL</label>
                <input type="text" class="form-control" name="url" value="<?php echo e($editvendor->url); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Map Lattitude</label>
                <input type="text" class="form-control" name="map_lattitude" value="<?php echo e($editvendor->map_lattitude); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Map Longitude</label>
                <input type="text" class="form-control" name="map_longitude" value="<?php echo e($editvendor->map_longitude); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">Shop in App</label>
                <select class="form-control" name="shop_in_app">
                    <option value="1" <?php echo e($editvendor->shop_in_app==1?'selected':""); ?>>Yes</option>
                    <option value="0" <?php echo e($editvendor->shop_in_app==0?'selected':""); ?>>No</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xyz\resources\views/layout/editvendor.blade.php ENDPATH**/ ?>