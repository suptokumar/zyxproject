
<?php $__env->startSection("title",__("ZYX Admin Panel")); ?>
<?php $__env->startSection("page"); ?>
<div class="breadcrumb">
    <h1>ZYX</h1>
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
        <li>Edit vendor</li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>


<div class="row justify-content-center">
    <div class="col-md-6">
        <form action="<?php echo e(url('/api/update-vendor')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="vendor_id" value="<?php echo e($editvendor->id); ?>">
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($editvendor->name); ?>" id="" aria-describedby="emailHelp" placeholder="Enter Name">
            </div>
            <div class="form-group">
                <label for="">Email address</label>
                <input type="email" class="form-control" name="email" value="<?php echo e($editvendor->email); ?>" id="" aria-describedby="emailHelp"placeholder="Enter email">
            </div>
            <div class="form-group">
                <label for="">Password </label>
                <input type="text" class="form-control" name="password" value="<?php echo e($editvendor->password); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">otp Verified </label>
                <input type="text" class="form-control" name="otp_verified" value="<?php echo e($editvendor->otp_verified); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">store_name </label>
                <input type="text" class="form-control" name="store_name" value="<?php echo e($editvendor->store_name); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">store_category </label>
                <input type="text" class="form-control" name="store_category" value="<?php echo e($editvendor->store_category); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">store_category_id</label>
                <input type="text" class="form-control" name="store_category_id" value="<?php echo e($editvendor->store_category_id); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">country_code </label>
                <input type="text" class="form-control" name="country_code" value="<?php echo e($editvendor->country_code); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">whatsapp</label>
                <input type="text" class="form-control" name="whatsapp" value="<?php echo e($editvendor->whatsapp); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">phone</label>
                <input type="text" class="form-control" name="phone" value="<?php echo e($editvendor->phone); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">address</label>
                <input type="text" class="form-control" name="address" value="<?php echo e($editvendor->address); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">logo</label>
                <input type="text" class="form-control" name="logo" value="<?php echo e($editvendor->logo); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">featured_image</label>
                <input type="text" class="form-control" name="featured_image" value="<?php echo e($editvendor->featured_image); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">url</label>
                <input type="text" class="form-control" name="url" value="<?php echo e($editvendor->url); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">map_lattitude</label>
                <input type="text" class="form-control" name="map_lattitude" value="<?php echo e($editvendor->map_lattitude); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">map_longitude</label>
                <input type="text" class="form-control" name="map_longitude" value="<?php echo e($editvendor->map_longitude); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <div class="form-group">
                <label for="">shop_in_app</label>
                <input type="text" class="form-control" name="shop_in_app" value="<?php echo e($editvendor->shop_in_app); ?>" id="" aria-describedby="emailHelp" placeholder="">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zyxproject\resources\views/layout/editvendor.blade.php ENDPATH**/ ?>