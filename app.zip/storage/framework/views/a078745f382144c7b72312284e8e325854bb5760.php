
        <div class="side-content-wrap">
            <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
                <ul class="navigation-left">
                    <li class="nav-item re_active">
                        <a class="nav-item-hold" href="<?php echo e(url('/')); ?>">
                            <i class="nav-icon i-Dashboard"></i>
                            <span class="nav-text">Dashboard</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="vendor">
                        <a class="nav-item-hold" href="<?php echo e(url('vendor')); ?>">
                            <i class="nav-icon i-Shop-2"></i>
                            <span class="nav-text">Vendor Management</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="sponsored_vendor_plans">
                        <a class="nav-item-hold" href="<?php echo e(url('sponsored_vendor_plans')); ?>">
                            <i class="nav-icon i-Folder-Search"></i>
                            <span class="nav-text">Sponsored Vendor Plans</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="featured_vendor_plans">
                        <a class="nav-item-hold" href="<?php echo e(url('featured_vendor_plans')); ?>">
                            <i class="nav-icon i-Folder-Search"></i>
                            <span class="nav-text">Featured Vendor Plans</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="customer_management">
                        <a class="nav-item-hold" href="<?php echo e(url('customer_management')); ?>">
                            <i class="nav-icon i-Management"></i>
                            <span class="nav-text">Customer Management</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="driver_management">
                        <a class="nav-item-hold" href="<?php echo e(url('driver_management')); ?>">
                            <i class="nav-icon i-Optimization"></i>
                            <span class="nav-text">Driver Management</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="chats">
                        <a class="nav-item-hold" href="<?php echo e(url('chats')); ?>">
                            <i class="nav-icon i-Mail-Unread"></i>
                            <span class="nav-text">Chats</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="FAQs">
                        <a class="nav-item-hold" href="<?php echo e(url('FAQs')); ?>">
                            <i class="nav-icon i-Folder-Search"></i>
                            <span class="nav-text">FAQs</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="system">
                        <a class="nav-item-hold" href="<?php echo e(url('system')); ?>">
                            <i class="nav-icon i-Management"></i>
                            <span class="nav-text">System Management</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="banners">
                        <a class="nav-item-hold" href="<?php echo e(url('banners')); ?>">
                            <i class="nav-icon i-Posterous"></i>
                            <span class="nav-text">Banners Management</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="notifications">
                        <a class="nav-item-hold" href="<?php echo e(url('notifications')); ?>">
                            <i class="nav-icon i-Mail-3"></i>
                            <span class="nav-text">Send Notifications</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
    
                    <li class="nav-item" data-item="coupons">
                        <a class="nav-item-hold" href="<?php echo e(url('coupons')); ?>">
                            <i class="nav-icon i-Ticket"></i>
                            <span class="nav-text">Coupons Management</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="custom_pages">
                        <a class="nav-item-hold" href="<?php echo e(url('custom_pages')); ?>">
                            <i class="nav-icon i-Ticket"></i>
                            <span class="nav-text">Custom Pages</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="subdomains">
                        <a class="nav-item-hold" href="<?php echo e(url('subdomains')); ?>">
                            <i class="nav-icon i-Globe"></i>
                            <span class="nav-text">SubAdmins</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="logs">
                        <a class="nav-item-hold" href="<?php echo e(url('logs')); ?>">
                            <i class="nav-icon i-Code-Window"></i>
                            <span class="nav-text">Logs</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
                    <li class="nav-item" data-item="settings">
                        <a class="nav-item-hold" href="<?php echo e(url('settings')); ?>">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="nav-text">Settings</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
    
    
                </ul>
            </div>

            <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">


                <ul class="childNav" data-parent="vendor">
                    <li class="nav-item">
                        <a href="<?php echo e(url('view/allvendor')); ?>">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View All Vendors</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.layouts.html">
                            <i class="nav-icon i-Approved-Window"></i>
                            <span class="item-name">Vendor Approvals</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.input.group.html">
                            <i class="nav-icon i-Statistic"></i>
                            <span class="item-name">Vendor Stats</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.validation.html">
                            <i class="nav-icon i-Paypal"></i>
                            <span class="item-name">Vendor Payouts</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('create/vendor')); ?>">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Create New Vendor</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tag.input.html">
                            <i class="nav-icon i-Folder-Settings"></i>
                            <span class="item-name">Approve Products </span>
                        </a>
                    </li>
                </ul>


                <ul class="childNav" data-parent="settings">
                    <li class="nav-item">
                        <a href="form.basic.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">Product Unit</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.layouts.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">Payment Gateways</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.input.group.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">Vendor Stats</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.validation.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">Default Delivery Radius</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="smart.wizard.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">SMS Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tag.input.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">WhatsApp Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tag.input.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">Maps Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tag.input.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">Powered by text</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tag.input.html">
                            <i class="nav-icon i-Settings-Window"></i>
                            <span class="item-name">App Settings</span>
                        </a>
                    </li>
                </ul>


                <ul class="childNav" data-parent="driver_management">
                    <li class="nav-item">
                        <a href="form.basic.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">Pending Requests</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.basic.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">All Drivers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.layouts.html">
                            <i class="nav-icon i-Approved-Window"></i>
                            <span class="item-name">Add Driver</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.input.group.html">
                            <i class="nav-icon i-Statistic"></i>
                            <span class="item-name">Track Drivers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="form.validation.html">
                            <i class="nav-icon i-Paypal"></i>
                            <span class="item-name">Delivery Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="smart.wizard.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Payout Requests</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tag.input.html">
                            <i class="nav-icon i-Folder-Settings"></i>
                            <span class="item-name">Driver Deposits</span>
                        </a>
                    </li>
                </ul>
                <ul class="childNav" data-parent="customer_management">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">List All</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Create New</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="custom_pages">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">List Custom page</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Add Custom Page</span>
                        </a>
                    </li>
                </ul>
                
                
                <ul class="childNav" data-parent="subdomains">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View List</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Create New</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="logs">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">Admin Panel Logs</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">User App Logs</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">Vendor App Logs</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">Driver App Logs</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">Vendor Sites Logs</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="chats">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Mail-Send"></i>
                            <span class="item-name">Chat with Vendors</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Mail-Send"></i>
                            <span class="item-name">Chat with Customers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Mail-Send"></i>
                            <span class="item-name">Chat with Drivers</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="FAQs">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View All</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Add New</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Optimization"></i>
                            <span class="item-name">Manage Category</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="coupons">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View Coupons</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Add Coupons</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View Bank offers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Add Bank offers</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="notifications">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Mail-3"></i>
                            <span class="item-name">Send notification by FCM</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Mail-3"></i>
                            <span class="item-name">Send notification by Email</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Mail-3"></i>
                            <span class="item-name">Send Notification by WhatsApp</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Mail-3"></i>
                            <span class="item-name">Send Notification by SMS</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="banners">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">List Banner</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Create Banner</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="system">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">Vendor Type</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Product Fields</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Optimization"></i>
                            <span class="item-name">Vendor Categories</span>
                        </a>
                    </li>
                </ul>
                
                <ul class="childNav" data-parent="featured_vendor_plans">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View Plans</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Add Plan</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v3.html">
                            <i class="nav-icon i-Optimization"></i>
                            <span class="item-name">Upgrade Requests</span>
                        </a>
                    </li>
                </ul>
                


                <ul class="childNav" data-parent="sponsored_vendor_plans">
                    <li class="nav-item">
                        <a href="dashboard.v1.html">
                            <i class="nav-icon i-Full-View-Window"></i>
                            <span class="item-name">View Plans</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v2.html">
                            <i class="nav-icon i-Add"></i>
                            <span class="item-name">Add Plan</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="dashboard.v3.html">
                            <i class="nav-icon i-Optimization"></i>
                            <span class="item-name">Upgrade Requests</span>
                        </a>
                    </li>
                </ul>
                



                <!-- Submenu Dashboards -->

            </div><?php /**PATH C:\xampp\htdocs\xyz\resources\views/layout/menu.blade.php ENDPATH**/ ?>